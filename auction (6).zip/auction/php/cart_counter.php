<?php
if (isset($_SESSION['email'])) { 
	include 'config.php';
	$email = mysqli_real_escape_string($conn,$_SESSION['email']);
	$select = $conn->query("SELECT * FROM cart WHERE status=0 AND email='$email'");
	echo $select->num_rows;
}else{
	echo 0;
}



 ?>