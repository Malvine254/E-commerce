<?php 
include 'config.php';
$select = $conn->query("SELECT * FROM category");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		$categories =explode(",", $row['categories']);
		echo "<a class=\"dropdown-item\" href=\"shop.php?id=".$row['product']."\">".$row['product']."</a>";
		
		
	}
}




 ?>