<?php 
include 'config.php';
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$select = $conn->query("SELECT * FROM category WHERE product='$id'");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		$categories =explode(",", $row['categories']);
		echo "<div class='col-md-4 col-lg-2 sidebar'>
		    		<div class='sidebar-box-2'>
		    			<h2 class='heading mb-4'><a href='?prdct=".$row['id']."'>".$row['product']."</a></h2>
		    			";
		for ($i=0; $i < count($categories); $i++) { 
			echo "<ul>
				<li><a href='?id=".$id."&c=".$categories[$i]."'> ".$categories[$i]."</a></li>
				</ul>";
			
		}
		echo "</div>
    			</div>";
		
	}
}

}else{
$select = $conn->query("SELECT * FROM category");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		$categories =explode(",", $row['categories']);
		echo "<div class='col-md-4 col-lg-2 sidebar'>
		    		<div class='sidebar-box-2'>
		    			<h2 class='heading mb-4'><a href='#'>".$row['product']."</a></h2>
		    			";
		for ($i=0; $i < count($categories); $i++) { 
			echo "<ul>
				<li><a href='#'> ".$categories[$i]."</a></li>
				</ul>";
			
		}
		echo "</div>
    			</div>";
		
	}
}
}




 ?>