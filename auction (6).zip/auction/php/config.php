<?php 

$conn = new mysqli("localhost","root","","myDb");
if ($conn) {
	//echo "connected";
}else{
	echo "connection error";
}


 ?>