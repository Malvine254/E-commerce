<?php
	if (isset($_SESSION['email'])) {
		include 'config.php';
		$email = $_SESSION['email'];
		$select = $conn->query("SELECT * FROM messages WHERE receiver='$email' AND status=0");
		echo $select->num_rows;
	}else{
		echo 0;
	} 
	
	 

 ?>