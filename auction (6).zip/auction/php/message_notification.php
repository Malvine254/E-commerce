<?php 
if (isset($_SESSION['email'])) {
	include 'config.php';
	$email = $_SESSION['email'];
	$select = $conn->query("SELECT * FROM messages WHERE receiver='$email' AND status=0");
	if ($select->num_rows>0) {
	 while ($row=$select->fetch_assoc()) {
	 	echo "<a class=\"dropdown-item\" href=\"contact.php?message=".$row['id']."#".$row['id']."\">New message from <b>".$row['name']." (Admin)</b></a>";
	  }
	}else{
	  echo "<a class=\"dropdown-item\" href=\"contact.php\">No new message found</b></a>";
	}
}else{
	echo "<a href='#' class=\"dropdown-item\">Login Required!!</a>";
}

 ?>