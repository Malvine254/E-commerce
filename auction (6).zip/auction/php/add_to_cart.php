<?php 
if (isset($_GET['i'])) {
	date_default_timezone_set('Africa/Nairobi');
	$time_stamp = time();
	if (isset($_SESSION['email'])) {
	include 'config.php';
	$id = mysqli_real_escape_string($conn,$_GET['i']);
	$select = $conn->query("SELECT * FROM products WHERE id='$id'");
	$email = $_SESSION['email'];
	while ($row=$select->fetch_assoc()) {
		$product_name = $row['product_name'];
		$product_price = $row['product_price'];
		$product_image = $row['product_image'];
		$quantity = $row['available_stock'];
		$select2 = $conn->query("SELECT * FROM cart WHERE unique_id='$id' AND email='$email' AND status=0");
		if ($select2->num_rows>0) {
			while($row2=$select2->fetch_assoc()){
				$final_quantity = $row2['quantity']+1;
				$stock_number = $quantity+$final_quantity;
				$update = $conn->query("UPDATE  cart SET product_name='$product_name',product_price='$product_price',product_image='$product_image',email='$email',unique_id='$id',quantity='$final_quantity', time_stamp='$time_stamp' WHERE unique_id='$id' AND email='$email'");
				if ($update) {
					$conn->query("UPDATE  products SET status='$stock_number' WHERE id='$id'");
					echo "<script>alert('Item addedd to cart again')</script>";
				}
			}
			
		}else{
			$insert = $conn->query("INSERT INTO cart(product_name,product_price,product_image,email,unique_id,time_stamp) VALUES('$product_name','$product_price','$product_image','$email','$id','$time_stamp')");
			if ($insert) {
				echo "<script>alert('Item addedd to cart')</script>";
			}
			
			}

		

	}
}else{
	echo "<script>alert('Login required');window.location.assign('login/')</script>";
}
}else if (isset($_GET['d'])) {
	date_default_timezone_set('Africa/Nairobi');
	$time_stamp = time();
	if (isset($_SESSION['email'])) {
	include 'config.php';
	$id = mysqli_real_escape_string($conn,$_GET['d']);
	$select = $conn->query("SELECT * FROM products WHERE id='$id'");
	$email = $_SESSION['email'];
	while ($row=$select->fetch_assoc()) {
		$product_name = $row['product_name'];
		$product_price = $row['product_price'];
		$product_image = $row['product_image'];
		$select2 = $conn->query("SELECT * FROM cart WHERE unique_id='$id' AND email='$email' AND status=0");
		if ($select2->num_rows>0) {
			while($row2=$select2->fetch_assoc()){
				$final_quantity = $row2['quantity']+1;
				$update = $conn->query("UPDATE  cart SET product_name='$product_name',product_price='$product_price',product_image='$product_image',email='$email',unique_id='$id',quantity='$final_quantity', time_stamp='$time_stamp' WHERE unique_id='$id' AND email='$email'");
				if ($update) {
					echo "<script>alert('Item addedd to cart');window.location.assign('cart.php')</script>";
				}
			}
			
		}else{
			$insert = $conn->query("INSERT INTO cart(product_name,product_price,product_image,email,unique_id,time_stamp) VALUES('$product_name','$product_price','$product_image','$email','$id','$time_stamp')");
			if ($insert) {
				echo "<script>alert('Item addedd to cart');window.location.assign('cart.php')</script>";
			}
			
			}

		

	}
}else{
	echo "<script>alert('Login required');window.location.assign('login/')</script>";
}
}



 ?>