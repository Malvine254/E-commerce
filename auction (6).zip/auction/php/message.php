<?php 
//if (isset($_POST['send_message_btn'])) {
date_default_timezone_set('Africa/Nairobi');
	include 'config.php';
	$subject = mysqli_real_escape_string($conn,$_POST['subject']);
	$time_now = date('h:i:sa  d-m-y');
	$message = mysqli_real_escape_string($conn,$_POST['message']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$select = $conn->query("SELECT * FROM users WHERE email='$email'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$name = $row['fname'] . $row['lname'];
			$insert = $conn->query("INSERT INTO messages (name,email,message,subject,time_now) VALUES('$name','$email','$message','$subject','$time_now')");
			if ($insert) {
				echo "Sent Successfully";
			}else{
				echo  "Not Sent";
			}
		}
	}

//}



 ?>