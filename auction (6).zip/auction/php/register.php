<?php 
if (isset($_POST['register_btn'])) {
	include "config.php";
	$lname = mysqli_real_escape_string($conn,$_POST['lname']);
	$fname = mysqli_real_escape_string($conn,$_POST['fname']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$username = mysqli_real_escape_string($conn,$_POST['username']);
	$gender = mysqli_real_escape_string($conn,$_POST['gender']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$location = mysqli_real_escape_string($conn,$_POST['location']);
	$confirmPassword = mysqli_real_escape_string($conn,$_POST['confirmPassword']);
	$encPassword = md5($password);
	$checkEmail = $conn->query("SELECT  * FROM users WHERE email='$email'");
	if ($checkEmail->num_rows>0) {
		echo "<div id='fadeAway' class='card text-center alert alert-danger text-dark'><strong>Email Address already taken</strong></div>";
	}else{
			if ($confirmPassword==$password) {
			$id = rand(500,50000);
			$result = $conn->query("INSERT INTO users (fname,lname,email,gender,username,password,location) VALUES ('$fname','$lname','$email','$gender','$username','$encPassword','$location')");
				if ($result) {
					echo "<script>alert('Registration Successful');window.location.assign('index.php')</script>";
				}else{
					echo "<script>alert('Failed to Sent Message')</script>";
				}

			}else{
				echo "<div id='fadeAway' class='card text-center alert alert-danger'><strong>Passwords do Not Match!!</strong></div>";
				
			}

		
		
		}
		
}
		
	

	


 ?>