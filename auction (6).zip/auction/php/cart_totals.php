<?php 
if (isset($_SESSION['email'])) {
	include 'php/config.php';
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
$select = $conn->query("SELECT * FROM cart WHERE status=0 AND email='$email'");
$total = 0;
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		$total = $total+$row['product_price'];
	}
	echo $total;

}
}else{
	echo 0;
}


 ?>