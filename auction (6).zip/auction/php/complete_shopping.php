<?php 
if (isset($_SESSION['email'])) {
if (isset($_POST['complete_shopping_btn'])) {
	include 'config.php';
	date_default_timezone_set("Africa/Nairobi");
	$location = mysqli_real_escape_string($conn,$_POST['location']);
	$username = mysqli_real_escape_string($conn,$_POST['username']);
	$email = mysqli_real_escape_string($conn,$_SESSION['email']);
	$time_now =date('h:i:sa d-m-y');
	$select = $conn->query("UPDATE cart SET location='$location',username='$username', status=1 WHERE email='$email' AND status=0");
	if ($select) {
		$insert = $conn->query("INSERT INTO messages (name,email,message,subject,time_now) VALUES('$username','$email','You have a pending order','New Order','$time_now')");
			if ($insert) {
				echo "<script>alert('Your order has been recieved');window.location.assign('index.php');</script>";
			}else{
				echo  "Not Sent";
			}
			
		}else{
			echo "<script>alert('Failed')</script>";
		}

}
}else{
	echo "Login";
}


 ?>