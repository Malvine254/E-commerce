<?php 
session_start();
if(isset($_SESSION['email'])){
	include 'config.php';
	$email = $_SESSION['email'];
	$select = $conn->query("SELECT * FROM messages");
	if ($select->num_rows>0) {
	 while ($row=$select->fetch_assoc()) {
	  if ($row['email']===$email && $row['receiver'] != $email) {
	    echo " <h6 id='".$row['id']."'></h6><p class=\"shadow\">
	            <h5>You (".$row['time_now'].")</h5>
	            <span ><b>".$row['subject']."</b>:  ".$row['message']."
	           </span>
	          </p><hr>";
	  }else if($row['receiver'] === $email && $row['email'] !=$email){
	    echo messagesStatus($row['status'],$row['name'],$row['message'],$row['subject'],$row['time_now']);
	  }
	  }
	}else{
	  echo " <p class=\"shadow\">
	            <h5></h5>
	            <span >No new messages found
	           </span>
	          </p>";
	}
	
}
function messagesStatus($status,$name,$message,$subject,$time){
		if ($status==0) {
			return "<div class='bg-danger text-light'><p class=\"bg-danger\" >
	            <h5	class='text-light'>".$name."(Admin) ".$time."</h5>
	            <span ><b>".$subject."</b>:  ".$message."
	           </span>
	          </p></div><hr>";
		}else{
			return "<p class=\"shadow\">
	            <h5>".$name."(Admin) ".$time."</h5>
	            <span ><b>".$subject."</b>:  ".$message."
	           </span>
	          </p><hr>";
		}
	}
 ?>