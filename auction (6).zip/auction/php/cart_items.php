<?php
if (isset($_SESSION['email'])) {
 	include 'php/config.php';
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
$select = $conn->query("SELECT * FROM cart WHERE status=0 AND email='$email'");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		echo " <tbody><tr class='text-center'>
			<td class='product-remove'><a href='#'><span class='ion-ios-close'></span></a></td>

			<td class='image-prod'><div class='img' style='background-image:url(".$row['product_image'].");'></div></td>

			<td class='product-name'>
			<h3>".$row['product_name']."</h3>
			<p>Far far away, behind the word mountains, far from the countries</p>
			</td>

			<td class='price'>$4.90</td>

			<td class='quantity'>
			<div class='input-group mb-3'>
				<input disabled type='text' name='quantity' class='quantity form-control input-number' value='".$row['quantity']."' min='1' max='100'>
			</div>
			</td>

			<td class='total'>$ ".$row['product_price'].".00</td>
			</tr></tbody>
			";
	}
}else{
	echo "<tbody>
			<tr>
				<td class='text-danger' colspan='6'><i>No item added to cart<i></td>
			</tr>
	</tbody>";
}
 } else{
 	echo "<tbody>
			<tr>
				<td class='text-danger' colspan='6'><i>Please Login<i></td>
			</tr>
	</tbody>";
 }


						    	 ?>