-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2022 at 05:58 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL DEFAULT '81dc9bdb52d04dc20036dbd8313ed055',
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`name`, `email`, `password`, `id`) VALUES
('James Koech', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `product_name` varchar(100) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL DEFAULT 0,
  `location` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `time_stamp` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`product_name`, `product_price`, `product_image`, `email`, `unique_id`, `id`, `quantity`, `status`, `location`, `username`, `time_stamp`) VALUES
('FLORAL JACKQUARD PULLOVER', 45, 'images/product-2.jpg', 'owuormalvine75@gmail.com', 2, 1, 6, 1, 'Nairobi', 'melo', 1671956078),
('FLORAL JACKQUARD PULLOVER', 67, 'images/product-4.jpg', 'owuormalvine75@gmail.com', 1, 2, 2, 1, 'Nairobi', 'melo', 1671956078),
('FLORAL JACKQUARD PULLOVER', 67, 'images/product-4.jpg', 'luke@gmail.com', 1, 17, 4, 0, NULL, NULL, 1672073049),
('FLORAL JACKQUARD PULLOVER', 45, 'images/product-2.jpg', 'luke@gmail.com', 2, 18, 1, 0, NULL, NULL, 1672048207);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `product` varchar(100) NOT NULL,
  `categories` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `product`, `categories`) VALUES
(1, 'Men', 'shirts,trousers,shorts,sneakers'),
(2, 'Women', 'dress,sweatpant,sweater,jumpers,socks'),
(3, 'ddd', 'a,d,s');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `receiver` varchar(100) DEFAULT 'admin@gmial.com',
  `status` int(11) NOT NULL DEFAULT 0,
  `time_now` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `message`, `email`, `subject`, `receiver`, `status`, `time_now`) VALUES
(63, 'LukeAmayo', 'When is it', 'luke@gmail.com', 'Delevery', 'admin@gmial.com', 1, '06:43:06pm  25-12-22'),
(64, 'James Koech', 'Tomorrow morning', 'admin@gmail.com', 'Delevery', 'luke@gmail.com', 1, '06:45:26pm 25-12-22'),
(65, 'Amayo J', 'You have a pending order', 'luke@gmail.com', 'New Order', 'admin@gmial.com', 1, '11:10:14am 26-12-22'),
(66, 'James Koech', 'Very soon', 'admin@gmail.com', 'New Order', 'luke@gmail.com', 1, '11:35:42am 26-12-22');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `available_stock` int(100) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_price`, `product_image`, `category`, `available_stock`, `status`) VALUES
(1, 'FLORAL JACKQUARD PULLOVER', 67, 'images/product-4.jpg', 'Men', 2, 6),
(2, 'FLORAL JACKQUARD PULLOVER', 45, 'images/product-2.jpg', 'Women', 33, 0),
(3, 'sneakers', 67, 'images/product-1.jpg', 'Men', 67, 0),
(12, 'Women Jeans', 46, 'images/about-1.jpg', 'Women', 56, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fname`, `lname`, `username`, `email`, `password`, `gender`, `id`, `location`) VALUES
('Malvine', 'Owuor', 'melo', 'owuormalvine75@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'male', 1, 'Nairobi'),
('James', 'Koech', 'Koech Mr.', 'james@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'male', 3, 'Kisii'),
('Luke', 'Amayo', 'Amayo J', 'luke@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'male', 4, 'Kakamega');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
