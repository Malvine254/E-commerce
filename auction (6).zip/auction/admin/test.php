<?php 
session_start();
 include 'php/display_messages_table.php';


 ?>