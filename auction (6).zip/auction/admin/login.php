<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="../login/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS --> 
		<link rel="stylesheet" href="../login/css/style.css">
	</head>

	<body>

		<div class="wrapper" style="background-image: url('../login/images/bg-registration-form-1.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="../login/images/registration-form-1.jpg" alt="">
				</div>
				<form method="POST" action="">
					<center><span style="color:red;"><?php include 'php/login.php'; ?></span></center>
					<h3>Admin Login</h3>
					<div class="form-wrapper">
						<input name="email" type="text" placeholder="Email Address" class="form-control">
						<i class="zmdi zmdi-account"></i>
					</div>
					
					<div class="form-wrapper">
						<input name="password" type="password" placeholder="Password" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<button name="login_btn">Login
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>