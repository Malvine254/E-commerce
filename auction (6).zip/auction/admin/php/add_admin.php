<?php 
include '../../php/config.php';
$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$select = $conn->query("SELECT * FROM admins WHERE email='$email'");
if ($select->num_rows>0) {
	echo "Email Address taken!!";
}else{
	$result = $conn->query("INSERT INTO admins (name,email) VALUES ('$name','$email')");
if ($result) {
	echo "Admin Added Successful";
}else{
	echo "Failed";
}
}

	
 ?>