<?php 
include '../php/config.php';
$select = $conn->query("SELECT * FROM users");
$numbering = 1;
if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "
			<tr >
				<td>".$numbering++."</td>
				<td>".$row['fname']." ".$row['lname']."</td>
				<td>".$row['email']."</td>
				<td>".$row['location']."</td>
				<td>".$row['username']."</td>
				<td>".$row['gender']."</td>
				<td><a class='zmdi zmdi-delete text-danger' href='?i=".$row['id']."'>del</a></td>
			<tr>";
		}
	}else{
		echo "<tr >
				<td colspan='7'><center>No items found!</center></td>
				
			<tr>";
	}


 ?>