<?php 
session_start();
if (isset($_SESSION['useremail'])) {
	// code...
}else{
	header("location:login.php");
}

 ?>