<?php 
if (isset($_SESSION['email'])) {
	include '../php/config.php';
	$email = $_SESSION['useremail'];
	echo $conn->query("SELECT * FROM messages WHERE receiver !='$email' AND email !='$email' AND status=0")->num_rows;
}else{
	echo 0;
}


 ?>