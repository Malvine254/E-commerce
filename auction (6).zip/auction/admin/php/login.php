<?php 

if (isset($_POST['login_btn'])) {
	session_start();
	include "../php/config.php";
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$encPassword = md5($password);
	$checkEmail = $conn->query("SELECT  * FROM admins WHERE email='$email' AND password='$encPassword'");
	
	if ($checkEmail->num_rows>0) {
		
		$_SESSION['useremail']=$email;
		header("location:index.php");
		
	}else{
		echo "<div id='fadeAway' class='card text-center alert alert-danger text-light'><p>Incorrect Credentials!!</p></div>";
		}
	}
		
	

	


 ?>