<?php 
include '../../php/config.php';
$id = $_POST['id'];
$select = $conn->query("SELECT * FROM messages WHERE id='$id'");
while ($row=$select->fetch_assoc()) {
	echo "<div class='row'>
		 <div class='form-group col-md-6'>
				<input disabled id='subject' value='".$row['subject']."' type='text' placeholder='Subject' class='form-control'>
	              <i class='zmdi zmdi-account'></i>
          </div><br>
            <div class='form-group col-md-6'>
                <input value='".$row['message']."' type='text' disabled id='message' cols='30' rows='7' class='form-control' placeholder='Message'>
           </div><br>
           </div>
          ";
}


 ?>