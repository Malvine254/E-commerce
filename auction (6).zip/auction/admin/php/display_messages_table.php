<?php 
include '../php/config.php';
$email = $_SESSION['useremail'];
$select = $conn->query("SELECT * FROM messages");
$numbering = 1;
if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo messagesStatusTwo($row['status'],$numbering++,$row['name'],$row['message'],$row['id'],$row['subject'],$row['email'],$row['receiver'],$row['time_now']);
		}
	}else{
		echo "<tr >
				<td colspan='7'><center>No items found!</center></td>
				
			<tr>";
	}
function messagesStatusTwo($status,$numbering,$name,$message,$id,$subject,$email,$receiver,$time){
if ($status==0) {
	return "
	<tr class='bg-danger text-light'>
		<td>".$numbering."</td>
		<td>".$name."</td>
		<td>".$message."</td>
		<td><button data-toggle=\"modal\" data-target=\"#myId\"  type='button' id='buttonId".$id."' value='".$id."' class='btn btn-primary button' type='button'>Reply</button></td>
		<td>".$subject."</td>
		<td>".$email."</td>
		<td>".$receiver."</td>
		<td>".$time."</td>
		<td><a class='btn btn-light' href='?f=".$id."'>MarkRead</a></td>
		<td><a class='zmdi zmdi-delete text-light' href='?m=".$id."'>del</a></td>
	<tr>";
	
}else{
	return "
	<tr >
		<td>".$numbering++."</td>
		<td>".$name."</td>
		<td>".$message."</td>
		<td><button data-toggle=\"modal\" data-target=\"#myId\"  type='button' id='buttonId".$id."' value='".$id."' class='btn btn-primary button' type='button'>Reply</button></td>
		<td>".$subject."</td>
		<td>".$email."</td>
		<td>".$receiver."</td>
		<td>".$time."</td>
		<td><a href='#'>Read</a></td>
		<td><a class='zmdi zmdi-delete text-danger' href='?m=".$id."'>del</a></td>
	<tr>";
}
}

 ?>