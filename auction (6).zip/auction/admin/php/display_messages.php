<?php 
if (isset($_SESSION['useremail'])) {
	include '../php/config.php';
	$email = $_SESSION['useremail'];
	$select = $conn->query("SELECT * FROM messages WHERE receiver !='$email' AND email !='$email' AND status=0");
	if ($select->num_rows>0) {
	 while ($row=$select->fetch_assoc()) {
	 	echo "<a class=\"dropdown-item\" href=\"tables.php#messages\">New message from <b>".$row['email']."</b></a>";
	  }
	}else{
	  echo "<ul>
				<li><a href='#'> You have no messages</a></li>
				</ul>";
	}
}else{
	echo "<a href='#' class=\"dropdown-item\">Login Required!!</a>";
}

 ?>