<?php 
	$numbering = 1;
	$index = 1;
	include '../php/config.php';
		$users = $conn->query("SELECT * FROM cart ");
		if ($users->num_rows>0) {
			while ($row=$users->fetch_assoc()) {
				date_default_timezone_set("Africa/Nairobi");
				$time_now = time();
				$time_sent = $row['time_stamp'];
				$time_differnce = $time_now-$time_sent;
				$sec = $time_differnce%60;
				$hours = round($time_differnce/3600);
				$min = round($time_differnce/60);
				$day = round($hours/24);
				$week = round($day/7);
				$month = round($week/4);
				if (isset($_GET['r']) && $_GET['r']=="Daily") {
					if ($min>0 && $day<7) {

						echo 
				"
				<tr>
					<td>".$numbering++."</td>
					<td>".$row['product_name']."</td>
					<td>$ ".$row['product_price']."</td>
					<td><img width='50' height='50' src='../".$row['product_image']."'></td>
					<td>".$row['username']."</td>
					<td>".$row['email']."</td>
					<td>".$row['location']."</td>
					<td>".$row['quantity']."</td>
					<td>".finalTime($sec,$min,$hours,$day,$week,$month)."</td>
					<td><a class='zmdi zmdi-delete text-danger' href='?c=".$row['id']."'>del</a></td>
				</tr>
				";
					}
				}else if (isset($_GET['r']) && $_GET['r']=="Weekly") {
					if ($day>=7 && $day<=28) {

						echo 
				"
				<tr>
					<td>".$numbering++."</td>
					<td>".$row['product_name']."</td>
					<td>$ ".$row['product_price']."</td>
					<td><img width='50' height='50' src='../".$row['product_image']."'></td>
					<td>".$row['username']."</td>
					<td>".$row['email']."</td>
					<td>".$row['location']."</td>
					<td>".$row['quantity']."</td>
					<td>".finalTime($sec,$min,$hours,$day,$week,$month)."</td>
					<td><a class='zmdi zmdi-delete text-danger' href='?c=".$row['id']."'>del</a></td>
				</tr>
				";
					}
				}else if (isset($_GET['r']) && $_GET['r']=="Monthly") {
					if ($day>28 && $month<12 ) {

						echo 
				"
				<tr>
					<td>".$numbering++."</td>
					<td>".$row['product_name']."</td>
					<td>$ ".$row['product_price']."</td>
					<td><img width='50' height='50' src='../".$row['product_image']."'></td>
					<td>".$row['username']."</td>
					<td>".$row['email']."</td>
					<td>".$row['location']."</td>
					<td>".$row['quantity']."</td>
					<td>".finalTime($sec,$min,$hours,$day,$week,$month)."</td>
					<td><a class='zmdi zmdi-delete text-danger' href='?c=".$row['id']."'>del</a></td>
				</tr>
				";
					}
				}else if (isset($_GET['r']) && $_GET['r']=="Annual") {
					if ($month>12) {

						echo 
				"
				<tr>
					<td>".$numbering++."</td>
					<td>".$row['product_name']."</td>
					<td>$ ".$row['product_price']."</td>
					<td><img width='50' height='50' src='../".$row['product_image']."'></td>
					<td>".$row['username']."</td>
					<td>".$row['email']."</td>
					<td>".$row['location']."</td>
					<td>".$row['quantity']."</td>
					<td>".finalTime($sec,$min,$hours,$day,$week,$month)."</td>
					<td><a class='zmdi zmdi-delete text-danger' href='?c=".$row['id']."'>del</a></td>
				</tr>
				";
					}
				}else{
					echo 
				"	<tr>
				    <td>".$numbering++."</td>
					<td>".$row['product_name']."</td>
					<td>$ ".$row['product_price']."</td>
					<td><img width='50' height='50' src='../".$row['product_image']."'></td>
					<td>".$row['username']."</td>
					<td>".$row['email']."</td>
					<td>".$row['location']."</td>
					<td>".$row['quantity']."</td>
					<td>".finalTime($sec,$min,$hours,$day,$week,$month)."</td>
					<td><a class='zmdi zmdi-delete text-danger' href='?c=".$row['id']."'>del</a></td>
					</tr>
				";

				}

				
			}
		}else{
			echo "<tr><td colspan='9'><center class='text-center text-danger'>No data</center></td></tr>";
		}

					function finalTime ($sec,$min,$hour,$day,$week,$month){
					if ($min<59) {
						if ($min==1) {
							return $min." min ago";
						}else{
							return $min." mins ago";
						}

					}else if($hour<24 ){
						if ($hour==1) {
							return $hour." hour ago";
						}else{
							return $hour." hours ago";
						}

					}else if($day<7){
						if ($day==1) {
							return $day." day ago";
						}else{
							return $day." days ago";
						}
				
					}else if($week<4 ){
						if ($week==1) {
							return $week." week ago";
						}else{
							return $week." weeks ago";
						}


					}else if($month<12 ){
						if ($month==1) {
							return $month." month ago";
						}else{
							return $month." months ago";
						}


					}if ($sec<59) {
						if ($sec==1) {
							return $sec." Just now";
						}else{
							return $sec." secs ago";
						}

					}
				}




 ?>