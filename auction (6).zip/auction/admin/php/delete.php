<?php
include '../php/config.php'; 
if (isset($_GET['i'])) {
	$id = $_GET['i'];
	$select = $conn->query("DELETE FROM users WHERE id='$id'");
	if ($select) {
		echo "<script>window.location.assign('tables.php#users')</script>";
	}
}else if (isset($_GET['m'])) {
	$id = $_GET['m'];
	$select = $conn->query("DELETE FROM messages WHERE id='$id'");
	if ($select) {
		echo "<script>window.location.assign('tables.php#messages')</script>";
	}
}else if (isset($_GET['a'])) {
	$id = $_GET['a'];
	$all =$conn->query("SELECT * FROM admins");
	if ($all->num_rows==1) {
		echo "<script>alert('You cannot delete all admins');window.location.assign('tables.php#admins')</script>";
	}else{
		$select = $conn->query("DELETE FROM admins WHERE id='$id'");
	if ($select) {
		echo "<script>window.location.assign('tables.php#admins')</script>";
	}
	}
	
}else if (isset($_GET['p'])) {
	$id = $_GET['p'];
	$select = $conn->query("DELETE FROM products WHERE id='$id'");
	if ($select) {
		echo "<script>window.location.assign('tables.php#products')</script>";
	}
}else if (isset($_GET['c'])) {
	$id = $_GET['c'];
	$select = $conn->query("DELETE FROM cart WHERE id='$id'");
}else if (isset($_GET['f'])) {
	$id = $_GET['f'];
	$select = $conn->query("UPDATE messages SET status=1 WHERE id='$id'");
	if ($select) {
		echo "<script>window.location.assign('tables.php#messages')</script>";
	}
}



 ?>