<?php 
session_start();
include '../../php/config.php';
date_default_timezone_set('Africa/Nairobi');
$id = $_POST['id'];
$response = $_POST['response2'];
$time_now = date('h:i:sa d-m-y');
$email = $_SESSION['useremail'];
$select = $conn->query("SELECT * FROM messages WHERE id='$id'");
while ($row=$select->fetch_assoc()) {
	$subject = $row['subject'];
	$receiver = $row['email'];
	$selectAdmin = $conn->query("SELECT * FROM admins WHERE email='$email'");
	while ($row=$selectAdmin->fetch_assoc()) {
		$name = $row['name'];
		$insert = $conn->query("INSERT INTO messages (name,message,email,subject,receiver,time_now) VALUES('$name','$response','$email','$subject','$receiver','$time_now')");
	if ($insert) {
		echo "sent";
	}else{
		echo "failed";
	}
	}
	
}


 ?>