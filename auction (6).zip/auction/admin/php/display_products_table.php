<?php 
include '../php/config.php';
$select = $conn->query("SELECT * FROM products");
$numbering = 1;
if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "
			<tr >
				<td>".$numbering++."</td>
				<td>".$row['product_name']."</td>
				<td>$ ".$row['product_price']."</td>
				<td><img width='50' height='50' src='../".$row['product_image']."'></td>
				<td>".$row['category']."</td>
				<td>".availableStocks(($row['available_stock']-$row['status']))."</td>
				<td><a class='zmdi zmdi-delete text-danger' href='?p=".$row['id']."'>del</a></td>
			<tr>";
		}
	}else{
		echo "<tr >
				<td colspan='7'><center>No items found!</center></td>
				
			<tr>";
	}
	function availableStocks($stock_difference){
		if ($stock_difference<=1) {
			return "<i class='alert alert-danger text-light'>Out of stock</i>";
		}else{
			return $stock_difference;
		}
	}


 ?>