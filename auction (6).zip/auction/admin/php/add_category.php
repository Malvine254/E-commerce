<?php 
include '../../php/config.php';
$product = mysqli_real_escape_string($conn,$_POST['product']);
$product_category = mysqli_real_escape_string($conn,$_POST['product_category']);
$result = $conn->query("INSERT INTO category (product,categories) VALUES ('$product','$product_category')");
if ($result) {
	echo "Category Added Successful";
}else{
	echo "Failed";
}
	
 ?>