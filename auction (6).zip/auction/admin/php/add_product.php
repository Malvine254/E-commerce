<?php 
include '../../php/config.php';
$product_name = mysqli_real_escape_string($conn,$_POST['product_name']);
$product_price = mysqli_real_escape_string($conn,$_POST['product_price']);
$product_price = mysqli_real_escape_string($conn,$_POST['product_price']);
$product_image = $_FILES['product_image']['name'];
$product_price = mysqli_real_escape_string($conn,$_POST['product_price']);
$result = $conn->query("INSERT INTO category (product,categories) VALUES ('$product','$product_category')");
if ($result) {
	echo "Category Added Successful";
}else{
	echo "Failed";
}
	
 ?>