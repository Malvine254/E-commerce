<?php 
include '../../php/config.php';
$product_name = mysqli_real_escape_string($conn,$_POST['product_name']);
$product_price = mysqli_real_escape_string($conn,$_POST['product_price']);
$stock_number = mysqli_real_escape_string($conn,$_POST['stock_number']);
$product_category = mysqli_real_escape_string($conn,$_POST['product_category']);
$product_image = $_FILES['product_image']['name'];
$target = "../../images/".basename($product_image);
$path = "images/".basename($product_image);
if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target)) {
	$result = $conn->query("INSERT INTO products (product_name,product_price,category,product_image,available_stock) VALUES ('$product_name','$product_price','$product_category','$path','$stock_number')");
		if ($result) {
			echo "Product Added Successful";
		}else{
			echo "Failed";
		}
			echo "Upload successful";
}else{
	echo "failed";
}

	
 ?>