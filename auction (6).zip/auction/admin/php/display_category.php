<?php 
include '../php/config.php';
$select = $conn->query("SELECT * FROM category");
if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "<option value='".$row['product']."'>".$row['product']."</option>";
		}
	}else{
		echo "<option disabled class='text-danger'>Add Categories first</option>";
	}


 ?>