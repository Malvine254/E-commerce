<?php 
date_default_timezone_set("Africa/Nairobi");
echo time();



 ?>