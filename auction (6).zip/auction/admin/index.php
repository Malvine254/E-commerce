<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/ionicons.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body class="goto-here">
		<div class="py-1 bg-black">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
	    		<div class="col-lg-12 d-block">
		    		<div class="row d-flex">
		    			<div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
						    <span class="text">+ 1235 2355 98</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
						    <span class="text">youremail@email.com</span>
					    </div>
					    <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right">
						    <span class="text">3-5 Business days delivery &amp; Free Returns</span>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.html">Admin</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="index.php" class="nav-link">Dashboard</a></li>
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="report.php" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Report</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
                <a class="dropdown-item" href="reports.php?r=Daily">Daily</a>
                <a class="dropdown-item" href="reports.php?r=Weekly">Weekly</a>
                <a class="dropdown-item" href="reports.php?r=Monthly">Monthly</a>
                <a class="dropdown-item" href="reports.php?r=Annual">Annually</a>
              </div>
            </li>
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="tables.php" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tables</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
                <a class="dropdown-item" href="tables.php#users">Users</a>
                <a class="dropdown-item" href="tables.php#messages">Messages</a>
                <a class="dropdown-item" href="tables.php#products">Products</a>
                <a class="dropdown-item" href="tables.php#admins">Admin</a>
              </div>
            </li>
            <li class="nav-item"><a href="forms.php" class="nav-link">Forms</a></li>
           <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="tables.php" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Notification <span class='text-danger'>[<?php include 'php/counter.php'; ?>]</span></a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
               <?php include 'php/display_messages.php'; ?>
              </div>
            </li>
            <?php if (isset($_SESSION['useremail'])): ?>
	          	<li class="nav-item"><a href="php/logout.php" class="nav-link">Logout</a></li>
	          <?php else: ?>
	          	<li class="nav-item"><a href="index.php" class="nav-link">Login</a></li>
	          <?php endif ?>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="ftco-section ftco-no-pb ftco-no-pt">
			<div class="container">
				<div class="row">
					<div class="col-md-12 py-5 wrap-about pb-md-5 ftco-animate">
	          <div class="heading-section-bold mb-4 mt-md-5">
	          	<div class="ml-md-0">
		            <h2 class="mb-4 text-center">DashBoard</h2>
	            </div>
	          </div>
	          <section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url(images/bg_4.jpg);">
			    	<div class="container">
			    		<div class="row justify-content-center py-5">
			    			<div class="col-md-10">
					    		<div class="row">
					          <div class="col-md-3 shadow d-flex justify-content-center counter-wrap ftco-animate">
					            <div class="block-18 text-center">
					              <div class="text">
					                <strong class="number" data-number="<?php include '../php/config.php'; echo $conn->query("SELECT * FROM users")->num_rows ?>">0</strong>
					                <span>Users</span>
					              </div>
					            </div>
					          </div>
					          <div class="col-md-3 shadow d-flex justify-content-center counter-wrap ftco-animate">
					            <div class="block-18 text-center">
					              <div class="text">
					                <strong class="number" data-number="<?php include '../php/config.php'; echo $conn->query("SELECT * FROM cart")->num_rows ?>">0</strong>
					                <span>Products Ordered</span>
					              </div>

					            </div>
					          </div>
					          <div class="col-md-3 shadow d-flex justify-content-center counter-wrap ftco-animate">
					            <div class="block-18 text-center">
					              <div class="text">
					                <strong class="number" data-number="<?php include '../php/config.php'; echo $conn->query("SELECT * FROM cart WHERE status=0")->num_rows ?>">0</strong>
					                <span>Pending Orders</span>
					              </div>
					            </div>
					          </div>
					          <div class="col-md-3 shadow d-flex justify-content-center counter-wrap ftco-animate">
					            <div class="block-18 text-center">
					              <div class="text">
					                <strong class="number" data-number="<?php include '../php/config.php'; echo $conn->query("SELECT * FROM messages")->num_rows ?>">0</strong>
					                <span>All Messages</span>
					              </div>
					            </div>
					          </div>
					        </div>
				        </div>
			        </div>
			    	</div>
    </section>
					</div>
				</div>
			</div>
		</section>
  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="../js/google-map.js"></script>
  <script src="../js/main.js"></script>
    
  </body>
</html>